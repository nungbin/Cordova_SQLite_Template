# Cordova (PhoneGap) SQLite Storage Example

Learn how to implement SQLite storage on your Cordova (PhoneGap) Projects for storing data offline.
Article: https://codesundar.com/cordova-sqlite-storage/
